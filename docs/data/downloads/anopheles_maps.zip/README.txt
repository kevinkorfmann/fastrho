fastrho Phase 2 mosquito maps
================================

Contents
--------
anopheles_maps.tsv.gz contains 50-kb population recombination-map windows for
nine open Ag1000G Phase 2 AR1 cohorts, five AgamP4 chromosome arms, and the
fixed 40-diploid inference panels.  It also carries cohort/species metadata and
panel-versus-full-release 2La summaries.

Coordinates and scale
---------------------
start_bp/end_bp are 0-based, half-open AgamP4 coordinates.  rho_per_bp is the
population-scaled output.  rate_per_bp and cM_per_Mb are already placed on an
absolute scale using the arm-specific auxiliary model estimate in Ne_used:

    rate_per_bp = rho_per_bp / (4 * Ne_used)
    cM_per_Mb   = rate_per_bp * 1e8

Do not divide rate_per_bp or cM_per_Mb by Ne again.  No rescaling is needed to
plot the released values.  If an independently justified effective population
size Ne_target is preferred, recompute the conditional absolute columns from
rho_per_bp as rho_per_bp / (4 * Ne_target) and multiply by 1e8 for cM/Mb.
Ne_used is an auxiliary model point estimate, not an independently validated
demographic or census estimate.  Absolute comparisons therefore remain
conditional on the selected Ne; retain rho_per_bp for the released
population-scaled quantity.

Verification
------------
The parent documentation download manifest records this archive's SHA-256 and
the table's row count, columns, source artifacts, byte size, and SHA-256.
Regenerate it with: python scripts/export_paper_data.py
