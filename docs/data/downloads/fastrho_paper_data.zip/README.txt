fastrho paper data
===================

Each table is a UTF-8, tab-delimited file compressed with gzip. Blank cells are missing values. Coordinates are 0-based half-open where start/end columns are present.

The active Anopheles analysis uses the open Ag1000G Phase 2 AR1 release: nine population panels of 40 mosquitoes across five chromosome arms. The map table labels 2La summaries from both the map panels and all eligible released samples. Its rho_per_bp column is population-scaled; rate_per_bp and cM_per_Mb are already converted with the arm-specific auxiliary estimate in Ne_used and must not be divided by Ne again. See resources/anopheles_maps.zip for the complete rescaling contract.

Map scales
----------
anopheles_maps.tsv.gz: rho_per_bp is population scaled; rate_per_bp and cM_per_Mb use the recorded Ne_used.
arabis_cross_maps.tsv.gz: dimensionless chromosome-relative rates with mean 1 within each map series.
arabidopsis_maps.tsv.gz: per-generation rates per bp at 100-kb resolution.
redpoll_maps.tsv.gz: population-scaled rho per bp at 500-kb resolution.
tree_of_life_maps.tsv.gz: per-generation rates per bp at 100-kb resolution; normalize within species for cross-species shape comparisons.
canid_example_map.tsv.gz: per-generation rates per bp for the simulated landscape and both inferred maps.

A column ending in _relative_rate is dimensionless and cannot be converted to cM/Mb. For a per-generation rate_per_bp column, cM/Mb = rate_per_bp * 1e8. Only the mosquito table records the Ne used for its absolute conversion. Treat inferred per-bp values in the Arabidopsis and tree-of-life tables as the archived paper scale for within-track comparisons, not as independently calibrated cross-species absolute rates.

The tables are plot-ready exports of the compact manuscript artifacts. See manifest.json for schemas, units, row counts, source artifacts, and SHA-256 checksums. The results/ directory contains the committed JSON snapshots behind reported paper metrics.
