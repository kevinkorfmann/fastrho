fastrho paper data
===================

Each table is a UTF-8, tab-delimited file compressed with gzip. Blank cells are missing values. Coordinates are 0-based half-open where start/end columns are present.

The active Anopheles analysis uses the open Ag1000G Phase 2 AR1 release: nine population panels of 40 mosquitoes across five chromosome arms. The map table labels 2La summaries from both the map panels and all eligible released samples.

The tables are plot-ready exports of the compact manuscript artifacts. See manifest.json for schemas, units, row counts, source artifacts, and SHA-256 checksums. The results/ directory contains the committed JSON snapshots behind reported paper metrics.
